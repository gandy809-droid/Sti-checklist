
import React, { useEffect, useMemo, useState } from "react";

const YES = "Yes" as const;
const NO = "No" as const;
const NA = "N/A" as const;

interface Photo {
  id: string;
  name: string;
  dataUrl: string;
  addedAt: number;
}

interface ChecklistItem {
  id: string;
  label: string;
  answer: typeof YES | typeof NO | typeof NA | "";
  hasType?: boolean;
  typeValue?: string;
  typeOptions?: string[];
  comments?: string;
  photos: Photo[];
}

interface Section {
  id: string;
  title: string;
  items: ChecklistItem[];
}

interface ChecklistDoc {
  id: string;
  title: string;
  facility?: string;
  location?: string;
  inspector?: string;
  date?: string;
  notes?: string;
  sections: Section[];
  version: string;
}

const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

const readFilesAsDataUrls = async (files: FileList | null): Promise<Photo[]> => {
  if (!files || files.length === 0) return [];
  const readers = Array.from(files).map(
    (file) =>
      new Promise<Photo>((resolve, reject) => {
        const fr = new FileReader();
        fr.onload = () =>
          resolve({
            id: uid(),
            name: file.name,
            dataUrl: String(fr.result),
            addedAt: Date.now(),
          });
        fr.onerror = reject;
        fr.readAsDataURL(file);
      })
  );
  return Promise.all(readers);
};

const download = (filename: string, content: string) => {
  const blob = new Blob([content], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
};

const seedSections = (): Section[] => [
  {
    id: uid(),
    title: "General Information",
    items: [
      { id: uid(), label: "Tank ID labeled/verified", answer: "", photos: [] },
      {
        id: uid(),
        label: "Tank orientation / configuration",
        answer: "",
        hasType: true,
        typeOptions: [
          "Vertical - cone roof",
          "Vertical - flat roof",
          "Horizontal - single wall",
          "Horizontal - double wall",
          "Other",
        ],
        photos: [],
      },
      {
        id: uid(),
        label: "Product stored identified",
        answer: "",
        hasType: true,
        typeOptions: ["Diesel", "Gasoline", "Lube Oil", "Chemicals", "Other"],
        photos: [],
      },
    ],
  },
  {
    id: uid(),
    title: "Foundation / Supports",
    items: [
      {
        id: uid(),
        label: "Foundation structurally sound (no settlement, cracks, spalling)",
        answer: "",
        photos: [],
      },
      {
        id: uid(),
        label: "Support type",
        answer: "",
        hasType: true,
        typeOptions: ["Concrete slab", "Ringwall", "Grating on beams", "Piers", "Soil"],
        photos: [],
      },
    ],
  },
  {
    id: uid(),
    title: "Shell / Bottom / Roof",
    items: [
      { id: uid(), label: "Shell free of leaks / weeps", answer: "", photos: [] },
      {
        id: uid(),
        label: "Coating/lining condition satisfactory",
        answer: "",
        hasType: true,
        typeOptions: ["Painted", "Uncoated", "Lined"],
        photos: [],
      },
      { id: uid(), label: "Roof free of deformation / damage", answer: "", photos: [] },
      { id: uid(), label: "Bottom condition acceptable (no active leaks)", answer: "", photos: [] },
    ],
  },
  {
    id: uid(),
    title: "Appurtenances",
    items: [
      {
        id: uid(),
        label: "Normal vent provided and operational",
        answer: "",
        photos: [],
      },
      {
        id: uid(),
        label: "Emergency vent provided (as applicable)",
        answer: "",
        photos: [],
      },
      {
        id: uid(),
        label: "Vent type",
        answer: "",
        hasType: true,
        typeOptions: ["Normal", "Emergency", "Combination", "PV valve"],
        photos: [],
      },
      { id: uid(), label: "Overfill prevention present and functional", answer: "", photos: [] },
      { id: uid(), label: "Leak detection (interstitial / sensors)", answer: "", photos: [] },
      { id: uid(), label: "Gauging / ATG operational", answer: "", photos: [] },
    ],
  },
  {
    id: uid(),
    title: "Containment / Drainage",
    items: [
      { id: uid(), label: "Secondary containment present and adequate", answer: "", photos: [] },
      {
        id: uid(),
        label: "Containment type",
        answer: "",
        hasType: true,
        typeOptions: ["Concrete dike", "Earthen berm", "Double-wall", "None"],
        photos: [],
      },
      { id: uid(), label: "Drains controlled and closed", answer: "", photos: [] },
    ],
  },
  {
    id: uid(),
    title: "Electrical Bonding / Grounding",
    items: [
      { id: uid(), label: "Bonding/grounding provided where required", answer: "", photos: [] },
    ],
  },
  {
    id: uid(),
    title: "Observations / Comments",
    items: [
      { id: uid(), label: "General comments", answer: NA, photos: [], hasType: false },
    ],
  },
];

const defaultDoc = (): ChecklistDoc => ({
  id: uid(),
  title: "STI SP001 Inspection Checklist",
  sections: seedSections(),
  version: "v1.0.0",
});

function Header({ doc, setDoc }: { doc: ChecklistDoc; setDoc: (d: ChecklistDoc) => void }) {
  const [expanded, setExpanded] = useState(true);
  return (
    <div className="bg-white/70 backdrop-blur sticky top-0 z-20 border-b">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="text-xl font-semibold">{doc.title}</div>
          <span className="text-xs px-2 py-1 rounded-full bg-gray-100 border">{doc.version}</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            className="px-3 py-1.5 rounded-lg border hover:bg-gray-50"
            onClick={() => setExpanded((v) => !v)}
            aria-label="Toggle project info"
          >
            {expanded ? "Hide Info" : "Show Info"}
          </button>
        </div>
      </div>
      {expanded && (
        <div className="max-w-6xl mx-auto px-4 pb-3 grid md:grid-cols-4 gap-3">
          <TextInput label="Facility" value={doc.facility || ""} onChange={(v) => setDoc({ ...doc, facility: v })} />
          <TextInput label="Location" value={doc.location || ""} onChange={(v) => setDoc({ ...doc, location: v })} />
          <TextInput label="Inspector" value={doc.inspector || ""} onChange={(v) => setDoc({ ...doc, inspector: v })} />
          <DateInput label="Date" value={doc.date || ""} onChange={(v) => setDoc({ ...doc, date: v })} />
          <div className="md:col-span-4">
            <TextArea label="Project Notes" value={doc.notes || ""} onChange={(v) => setDoc({ ...doc, notes: v })} />
          </div>
        </div>
      )}
    </div>
  );
}

function TextInput({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="block">
      <span className="text-sm text-gray-700">{label}</span>
      <input
        className="mt-1 w-full rounded-xl border px-3 py-2 focus:outline-none focus:ring-2"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}

function DateInput({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="block">
      <span className="text-sm text-gray-700">{label}</span>
      <input
        type="date"
        className="mt-1 w-full rounded-xl border px-3 py-2 focus:outline-none focus:ring-2"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}

function TextArea({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="block">
      <span className="text-sm text-gray-700">{label}</span>
      <textarea
        rows={3}
        className="mt-1 w-full rounded-xl border px-3 py-2 focus:outline-none focus:ring-2"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}

function AnswerPill({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const opts = [YES, NO, NA];
  return (
    <div className="inline-flex rounded-xl border overflow-hidden">
      {opts.map((op) => (
        <button
          key={op}
          className={`px-3 py-1.5 text-sm border-r last:border-r-0 ${
            value === op ? "bg-gray-900 text-white" : "bg-white hover:bg-gray-50"
          }`}
          onClick={() => onChange(op)}
          type="button"
        >
          {op}
        </button>
      ))}
    </div>
  );
}

function ItemCard({
  item,
  onChange,
  onAddPhotos,
  onDeletePhoto,
}: {
  item: ChecklistItem;
  onChange: (patch: Partial<ChecklistItem>) => void;
  onAddPhotos: (files: FileList | null) => void;
  onDeletePhoto: (photoId: string) => void;
}) {
  const hasDeficiency = item.answer === NO;
  return (
    <div className={`rounded-2xl border p-4 bg-white shadow-sm ${hasDeficiency ? "ring-2 ring-red-300" : ""}`}>
      <div className="flex flex-col gap-3 md:flex-row md:items-start md:gap-6">
        <div className="md:flex-1">
          <div className="font-medium text-gray-900">{item.label}</div>
          <div className="mt-2 flex flex-wrap items-center gap-3">
            <AnswerPill value={item.answer} onChange={(v) => onChange({ answer: v as any })} />
            {item.hasType && (
              <select
                className="rounded-xl border px-3 py-1.5"
                value={item.typeValue || ""}
                onChange={(e) => onChange({ typeValue: e.target.value })}
              >
                <option value="">Select type…</option>
                {(item.typeOptions || []).map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            )}
          </div>
          <div className="mt-3">
            <textarea
              placeholder="Comments (optional)"
              className="w-full rounded-xl border px-3 py-2 focus:outline-none focus:ring-2"
              rows={2}
              value={item.comments || ""}
              onChange={(e) => onChange({ comments: e.target.value })}
            />
          </div>
        </div>
        <div className="md:w-72 w-full">
          <label className="block text-sm text-gray-700 mb-1">Photos</label>
          <input
            type="file"
            accept="image/*"
            multiple
            onChange={async (e) => onAddPhotos(e.target.files)}
            className="block w-full text-sm"
          />
          {item.photos.length > 0 ? (
            <div className="mt-2 grid grid-cols-3 gap-2">
              {item.photos.map((p) => (
                <div key={p.id} className="relative group">
                  <img src={p.dataUrl} alt={p.name} className="h-20 w-full object-cover rounded-lg border" />
                  <button
                    type="button"
                    onClick={() => onDeletePhoto(p.id)}
                    className="absolute top-1 right-1 text-xs px-2 py-0.5 rounded-full bg-black/70 text-white opacity-0 group-hover:opacity-100"
                    aria-label="Remove photo"
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-2 text-xs text-gray-500">No photos added yet.</div>
          )}
        </div>
      </div>
      {hasDeficiency && (
        <div className="mt-3 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl p-2">
          Marked as <strong>Deficiency</strong> (answer = No). Ensure comments and photos are attached.
        </div>
      )}
    </div>
  );
}

function SectionBlock({ section, updateItem }: { section: Section; updateItem: (itemId: string, patch: Partial<ChecklistItem>) => void }) {
  return (
    <div className="space-y-3">
      {section.items.map((it) => (
        <ItemCard
          key={it.id}
          item={it}
          onChange={(patch) => updateItem(it.id, patch)}
          onAddPhotos={async (files) => {
            const photos = await readFilesAsDataUrls(files);
            updateItem(it.id, { photos: [...it.photos, ...photos] });
          }}
          onDeletePhoto={(photoId) => {
            updateItem(it.id, { photos: it.photos.filter((p) => p.id !== photoId) });
          }}
        />
      ))}
    </div>
  );
}

function Sidebar({
  sections,
  activeId,
  setActiveId,
}: {
  sections: Section[];
  activeId: string;
  setActiveId: (id: string) => void;
}) {
  return (
    <aside className="w-full md:w-64 shrink-0 border-r bg-white/60 backdrop-blur rounded-2xl md:rounded-none md:sticky md:top-[5.5rem] md:h-[calc(100vh-5.5rem)] overflow-auto">
      <div className="p-3">
        <div className="font-semibold text-gray-800 mb-2">Sections</div>
        <nav className="space-y-1">
          {sections.map((s, idx) => (
            <button
              key={s.id}
              className={`w-full text-left px-3 py-2 rounded-xl border ${
                activeId === s.id ? "bg-gray-900 text-white" : "bg-white hover:bg-gray-50"
              }`}
              onClick={() => setActiveId(s.id)}
            >
              {idx + 1}. {s.title}
            </button>
          ))}
        </nav>
      </div>
    </aside>
  );
}

function Toolbar({
  doc,
  setDoc,
}: {
  doc: ChecklistDoc;
  setDoc: (d: ChecklistDoc) => void;
}) {
  const [importing, setImporting] = useState(false);
  const [printMode, setPrintMode] = useState(false);

  useEffect(() => {
    document.body.classList.toggle("print-mode", printMode);
    return () => document.body.classList.remove("print-mode");
  }, [printMode]);

  const exportJson = () => {
    const nameBits = [doc.facility, doc.title, new Date().toISOString().slice(0, 10)]
      .filter(Boolean)
      .join(" - ")
      .replace(/\s+/g, " ");
    download(`${nameBits || "sti-sp001-checklist"}.json`, JSON.stringify(doc, null, 2));
  };

  const resetDoc = () => {
    if (!confirm("Start a fresh checklist? Unsaved changes will be lost.")) return;
    setDoc(defaultDoc());
  };

  return (
    <div className="flex flex-wrap gap-2">
      <button className="px-3 py-2 rounded-xl border hover:bg-gray-50" onClick={exportJson}>
        Export JSON
      </button>
      <label className="px-3 py-2 rounded-xl border hover:bg-gray-50 cursor-pointer">
        Import JSON
        <input
          type="file"
          accept="application/json"
          className="hidden"
          onChange={async (e) => {
            try {
              const file = e.target.files?.[0];
              if (!file) return;
              setImporting(true);
              const text = await file.text();
              const parsed = JSON.parse(text) as ChecklistDoc;
              if (!parsed || !Array.isArray(parsed.sections)) throw new Error("Invalid file.");
              setDoc(parsed);
            } catch (err) {
              alert("Failed to import JSON: " + (err as Error).message);
            } finally {
              setImporting(false);
              (e.target as HTMLInputElement).value = "";
            }
          }}
        />
      </label>
      <button className="px-3 py-2 rounded-xl border hover:bg-gray-50" onClick={() => window.print()}>Print</button>
      <button className={`px-3 py-2 rounded-xl border ${printMode ? "bg-gray-900 text-white" : "hover:bg-gray-50"}`} onClick={() => setPrintMode((v) => !v)}>
        {printMode ? "Exit Print View" : "Print View"}
      </button>
      <button className="px-3 py-2 rounded-xl border hover:bg-gray-50" onClick={resetDoc}>
        New Checklist
      </button>
      {importing && <span className="text-sm text-gray-500">Importing…</span>}
    </div>
  );
}

function AutosaveBadge() {
  const [blink, setBlink] = useState(false);
  useEffect(() => {
    const h = setInterval(() => setBlink((b) => !b), 1500);
    return () => clearInterval(h);
  }, []);
  return (
    <span className={`text-xs px-2 py-1 rounded-full border ${blink ? "bg-green-50" : "bg-white"}`}>Autosave on</span>
  );
}

export default function App() {
  const [doc, setDoc] = useState<ChecklistDoc>(() => {
    const saved = localStorage.getItem("sti_sp001_doc_v1");
    return saved ? (JSON.parse(saved) as ChecklistDoc) : defaultDoc();
  });
  const [activeId, setActiveId] = useState<string>(doc.sections[0]?.id || "");

  useEffect(() => {
    localStorage.setItem("sti_sp001_doc_v1", JSON.stringify(doc));
  }, [doc]);

  useEffect(() => {
    if (!doc.sections.find((s) => s.id === activeId)) {
      setActiveId(doc.sections[0]?.id || "");
    }
  }, [doc.sections, activeId]);

  const updateSection = (sectionId: string, updater: (s: Section) => Section) => {
    setDoc({
      ...doc,
      sections: doc.sections.map((s) => (s.id === sectionId ? updater(s) : s)),
    });
  };

  const addSection = () => {
    const title = prompt("New section title");
    if (!title) return;
    const newSection: Section = { id: uid(), title, items: [] };
    setDoc({ ...doc, sections: [...doc.sections, newSection] });
    setActiveId(newSection.id);
  };

  const removeSection = (sectionId: string) => {
    if (!confirm("Remove this section?")) return;
    setDoc({ ...doc, sections: doc.sections.filter((s) => s.id !== sectionId) });
  };

  const activeSection = useMemo(() => doc.sections.find((s) => s.id === activeId), [doc.sections, activeId]);

  const addItem = (sectionId: string) => {
    const label = prompt("Item label");
    if (!label) return;
    const hasType = confirm("Does this item have a Type dropdown?");
    const typeOptions = hasType ? prompt("Enter type options (comma separated)")?.split(",").map((s) => s.trim()).filter(Boolean) || [] : undefined;
    updateSection(sectionId, (s) => ({
      ...s,
      items: [
        ...s.items,
        { id: uid(), label, answer: "", hasType, typeOptions, photos: [] },
      ],
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <Header doc={doc} setDoc={setDoc} />

      <div className="max-w-6xl mx-auto px-3 md:px-4 py-4 md:py-6 grid md:grid-cols-[16rem_1fr] gap-4">
        <Sidebar sections={doc.sections} activeId={activeId} setActiveId={setActiveId} />

        <main>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-semibold">{activeSection?.title || "Untitled"}</h2>
              <AutosaveBadge />
            </div>
            <Toolbar doc={doc} setDoc={setDoc} />
          </div>

          {activeSection ? (
            <div className="space-y-4">
              <SectionBlock
                section={activeSection}
                updateItem={(itemId, patch) =>
                  updateSection(activeSection.id, (s) => ({
                    ...s,
                    items: s.items.map((it) => (it.id === itemId ? { ...it, ...patch } : it)),
                  }))
                }
              />

              <div className="flex flex-wrap gap-2">
                <button className="px-3 py-2 rounded-xl border hover:bg-gray-50" onClick={() => addItem(activeSection.id)}>
                  Add Item
                </button>
                <button className="px-3 py-2 rounded-xl border hover:bg-gray-50" onClick={() => addSection()}>
                  Add Section
                </button>
                {doc.sections.length > 1 && (
                  <button className="px-3 py-2 rounded-xl border hover:bg-red-50 text-red-600" onClick={() => removeSection(activeSection.id)}>
                    Remove Section
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="text-gray-500">No section selected.</div>
          )}
        </main>
      </div>

      <footer className="max-w-6xl mx-auto px-4 pb-10 pt-6 text-xs text-gray-500">
        <div>
          Built for STI SP001-style inspections. This demo does not enforce standard requirements; adjust items as needed.
        </div>
      </footer>

      <style>{`
        @media print {
          .print-mode .border, .print-mode .shadow-sm { box-shadow: none !important; }
          header, aside, nav, .sticky, .print-hide { display: none !important; }
          textarea { border: 1px solid #e5e7eb; }
          .ring-red-300 { outline: 2px solid #fecaca; }
          button { display: none !important; }
          input[type='file'] { display: none !important; }
        }
      `}</style>
    </div>
  );
}
