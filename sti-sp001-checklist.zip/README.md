
# STI SP001 Checklist (Vite + React + TypeScript + Tailwind)

A field-ready digital checklist for STI SP001 inspections: Yes/No answers (+ N/A), optional Type dropdowns, comments, and photo uploads per item; autosaves to the device; export/import JSON; print view.

## Quick Start (Local)
```bash
npm install
npm run dev
```

## Deploy to Vercel (recommended)
1) Create a new project on https://vercel.com → **Deploy Project** → **Import / Upload**.
2) Upload this folder (or the provided ZIP).
3) Vercel will detect **Vite** and set:
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
4) Click **Deploy**. You'll get a public URL to open on your iPhone.
5) On iPhone Safari: **Share → Add to Home Screen**.

## Notes
- All photos are stored as base64 in your browser's localStorage via JSON export/import.
- For very large photo sets, consider connecting to a backend later (S3 or similar).
